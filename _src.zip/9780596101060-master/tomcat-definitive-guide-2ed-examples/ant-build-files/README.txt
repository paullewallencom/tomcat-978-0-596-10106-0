This directory contains build files that are shown as examples in the book.
We can't name them all "build.xml", but when you're using them, you should
probably rename the build file "build.xml".
